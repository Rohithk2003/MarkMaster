package com.markmaster.MarkMaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarkMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
